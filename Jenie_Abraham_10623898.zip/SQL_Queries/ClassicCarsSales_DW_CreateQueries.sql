CREATE DATABASE ClassicCarsSales_DW
GO
USE ClassicCarsSales_DW
GO

CREATE TABLE Customer_Dim
(CustomerKey INT NOT NUll IDENTITY,
CustomerID INT,
CompanyName NVARCHAR(100),
ContactFirstName NVARCHAR(100),
ContactLastName NVARCHAR(100),
CustomerPhone NVARCHAR(100),
CustomerCity NVARCHAR(100),
CustomerCountry NVARCHAR(100),
CustomerCreditLimit FLOAT,
PRIMARY KEY (CustomerKey));
GO

CREATE TABLE Calendar_Dim
(
CalendarKey INT NOT NULL IDENTITY,
PaymentDate DATE,
DayofWeek_ CHAR(15),
DayType CHAR(20),
DayofMonth_ INT,
Month_	CHAR(10),
Quarter_ CHAR(2),
Year_ INT,
PRIMARY KEY (CalendarKey));
GO

CREATE TABLE Order_Dim
(OrderKey INT NOT NULL IDENTITY,
OrdeID INT,
OrderDate DATE,
OrderRequiredDate DATE,
OrderShippedDate DATE,
OrderStatus NVARCHAR(30),
ProductName NVARCHAR(510),
ProductLine NVARCHAR(510),
ProductVendorName NVARCHAR(510),
ProductQtyInStock FLOAT,
ProductMSRP FLOAT,
PRIMARY KEY (OrderKey));
GO

CREATE TABLE Employee_Dim
(EmployeeKey INT NOT NULL IDENTITY,
EmployeeID INT,
EmployeeFirstName NVARCHAR(100),
EmployeeLastName NVARCHAR(100),
EmployeeJobTitle VARCHAR(100),
EmployeeOfficeCode NVARCHAR(50),
EmployeeCountry NVARCHAR(100),
PRIMARY KEY (EmployeeKey));
GO

CREATE TABLE ClassicCarsSales_Fact
(
CustomerKey INT,
OrderKey INT,
EmployeeKey INT,
CalendarKey INT,
checkNumber NVARCHAR(100),
OrderLineNumber INT,
QtyOrdered INT,
DollarsSold FLOAT,
FOREIGN KEY (CalendarKey) REFERENCES Calendar_Dim (CalendarKey),
FOREIGN KEY (EmployeeKey) REFERENCES Employee_Dim (EmployeeKey),
FOREIGN KEY (OrderKey) REFERENCES Order_Dim (OrderKey),
FOREIGN KEY (CustomerKey) REFERENCES Customer_Dim(CustomerKey)
);

